// Play drum by keyboard press

// Play music by mouse click
