// Mapbox API token: pk.eyJ1IjoiYmVubWF1ZHNsYXkiLCJhIjoiY2p0N2RtOHB1MDJzbDN5bzh5c25zaDllZyJ9.D0RtSq3i_afvqrXX2jHFbg
const locationToken =
  "pk.eyJ1IjoiYmVubWF1ZHNsYXkiLCJhIjoiY2p0N2RtOHB1MDJzbDN5bzh5c25zaDllZyJ9.D0RtSq3i_afvqrXX2jHFbg"

// Dark Sky API token: 52679ca5ce13a04d4268223e9ea7d587
const weatherToken = "52679ca5ce13a04d4268223e9ea7d587"

module.exports = {
  weatherToken,
  locationToken
}
