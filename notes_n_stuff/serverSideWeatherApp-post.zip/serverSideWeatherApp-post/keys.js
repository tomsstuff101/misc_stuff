const weatherToken = process.env.WEATHER

const locationToken = process.env.LOCATION

module.exports = {
  weatherToken,
  locationToken
}
